import React from "react";
import "./style.css";
import "./style/opd.jsx"

function Main() {
  return (
    <div className="main">
      <div className="main_tag">
        <h1>WELCOME TO<br /><span>Medical Care</span></h1>
        <p>
          Now getting an OPD appointment, lab reports, and blood availability in any government hospital has become online and easy.
        </p>
        <a href="opd.jsx" className="main_btn">Appointment Now</a>
      </div>
      <div className="image-container">
        <img src="" alt="Main Visual" className="color-hover" />
      </div>
    </div>
  );
}

export default Main;
