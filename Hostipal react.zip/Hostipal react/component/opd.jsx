import React, { useState } from 'react';
import './style.css';


const opd = () => {
    const [patientData, setPatientData] = useState({
        name: '',
        age: '',
        gender: '',
        symptoms: '',
        diagnosis: '',
        prescription: ''
    });

    const handleChange = (e) => {
        setPatientData({ ...patientData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Patient Data Submitted:', patientData);
    };

    return (
        <div>
            <h2>OPD Medical Page</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Name:
                    <input type="text" name="name" value={patientData.name} onChange={handleChange} />
                </label>
                <label>
                    Age:
                    <input type="number" name="age" value={patientData.age} onChange={handleChange} />
                </label>
                <label>
                    Gender:
                    <select name="gender" value={patientData.gender} onChange={handleChange}>
                        <option value="">Select</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </label>
                <label>
                    Symptoms:
                    <textarea name="symptoms" value={patientData.symptoms} onChange={handleChange} />
                </label>
                <label>
                    Diagnosis:
                    <textarea name="diagnosis" value={patientData.diagnosis} onChange={handleChange} />
                </label>
                <label>
                    Prescription:
                    <textarea name="prescription" value={patientData.prescription} onChange={handleChange} />
                </label>
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default opd;
