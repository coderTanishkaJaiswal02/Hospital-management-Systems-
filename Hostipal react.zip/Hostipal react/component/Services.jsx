import React from "react";
import "./style/style.css";

function Services() {
  const servicesData = [
    {
      icon: "fa-laptop-medical",
      title: "Patient Registration (OPD Casualty, Appointment & ORS)",
      description: "The patient registration module of the e-Hospital application is used for patient registration in the OPD and Casualty departments as well as to book, confirm and cancel appointments."
    },
    {
      icon: "fa-bed-pulse",
      title: "Admission, Discharge & Transfer (IPD)",
      description: "The IPD module commences when the patient is being registered and allotted bed in the ward."
    },
    {
    icon:"fa-solid fa-receipt",
    title:"Billing",
    description:"The Billing module handles all types of billing workflows. This module facilitates cashier and billing operators for managing billing functions related to billing receipts and refunds.",
    },
    {
    icon:"fa-solid fa-file-medical",
   title:" Clinic (OPD & IPD)",
    description:" The Clinic module allows the clinicians and doctors to record the clinical data of the patients like visits, examination, diagnosis, history, treatment, prescriptions etc., and to order investigations, procedures and medicines, to keep track of the treatment and other services provided to the patients.",
    },
     {
     icon:"fa-solid fa-mobile-screen-button",
      title:"Queue Management Mobile App",
      description:" This app is to facilitate patient to share demographic data in assisted mode with hospital for OPD registration queue. Patients can share their demographic data using ABHA to add themselves in OPD queue. Alternately, if the patient does not have ABHA, he / she can still be added by operator in queue by using 'Without ABHA'option (More). ",
     },
  {
       icon:"fa-solid fa-bone",
       title:"Radiology Information system (RIS)",
       description:" The Radiology module automates the manual procedures used in the radiology services: ordering and scheduling of tests and procedures, review and verification of results, reporting of results and/or diagnoses for clinical treatment.",
    },
    {
       icon:"fa-solid fa-capsules",
        title:"Store & parmacy",
        description:"The Store & Pharmacy module is used for managing the stores and pharmacies along with generating indents and procuring/providing store items and medicines."
      },
    {
       icon:"fa-solid fa-gears",
       title:"OT Management",
       description:"The OT Management module automates the functions and workflows of operation theatres in the hospitals.",
    }
  ];

  return (
    <div className="services">
      <div className="services_box">
        {servicesData.map((service, index) => (
          <div className="services_card" key={index}>
            <i className={`fa-solid ${service.icon}`}></i>
            <h3>{service.title}</h3>
            <p>{service.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Services;
