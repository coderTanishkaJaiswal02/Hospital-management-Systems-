import React from "react";
import "./style.css";

function Navbar() {
  return (
    <nav>
      <div className="logo">
        <img src="photos/logo.webp" alt="Logo" />
      </div>
      <ul>
        <li><i className="fa-solid fa-house"></i><a href="index.jsx"> Home</a></li>
        <li><i className="fa-solid fa-user-doctor"></i><a href="specialities.html"></a>specialities</li>
        <li><i className="fa-solid fa-desktop"></i><a href="dashboard.jsx"> Dashboard</a></li>
        <li><i className="fa-solid fa-tower-broadcast"></i><a href="#LiveStatus"> Live Status</a></li>
        <li><i className="fa-solid fa-address-card"></i><a href="#AboutUs"> About Us</a></li>
      </ul>
      <div className="social_icon">
        <div className="login">
          <i className="fa-solid fa-arrow-right-to-bracket"></i>
          <a className="log" href="sign.jsx">Login Now</a>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
