import React from "react";
import "./style.css";

function About() {
  return (
    <div className="about">
      <div className="about_image">
        <img src="photos/drss.webp" alt="About Us" />
      </div>
      <div className="about_tag">
        <h1>About Us</h1>
        <p>
          The e-Hospital application is being offered as an as-is product to the government hospitals across the country through SaaS (Software as a Service) model.
        </p>
        <a href="#" className="about_btn">Learn More</a>
      </div>
    </div>
  );
}

export default About;
