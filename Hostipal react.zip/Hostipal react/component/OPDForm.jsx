import React, { useState } from "react";
import "./style/opd.css"

function OPDForm() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    age: "",
    medicalHistory: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Replace the URL with your API endpoint
    fetch("https://your-api-endpoint.com/submit", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    })
      .then((response) => {
        if (response.ok) {
          alert("Form submitted successfully!");
          setFormData({
            name: "",
            phone: "",
            age: "",
            medicalHistory: "",
          });
        } else {
          alert("Error submitting form. Please try again.");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("An error occurred. Please try again.");
      });
  };

  return (
    <section className="section">
      <div className="form-container">
        <marquee>
          Login/Signup before Registration <a href="sign.html">Login</a>
        </marquee>
        <h2>Outpatient Department Form</h2>
        <div className="form-input">
          <form onSubmit={handleSubmit}>
            <label htmlFor="name">Full Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />

            <label htmlFor="phone">Phone Number:</label>
            <input
              type="text"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
            />

            <label htmlFor="age">Age:</label>
            <input
              type="number"
              id="age"
              name="age"
              value={formData.age}
              onChange={handleChange}
              required
            />

            <label htmlFor="medicalHistory">Medical History:</label>
            <textarea
              id="medicalHistory"
              name="medicalHistory"
              rows="4"
              value={formData.medicalHistory}
              onChange={handleChange}
            ></textarea>

            <input type="submit" value="Submit" />
          </form>
        </div>
      </div>
    </section>
  );
}

export default OPDForm;
