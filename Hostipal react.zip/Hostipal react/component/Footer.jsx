import React from "react";
import "./style/Footer.css";

function Footer() {
  return (
    <footer>
      <div className="page" align="center">
        <a href="#">Condition of Use</a>
        <a href="#">Privacy Notice</a>
        <a href="#">Your Ads Privacy Choices</a>
      </div>
      <div className="copyright" align="center">
        © 1996-2024, HMS, Inc. or its affiliates
      </div>
    </footer>
  );
}

export default Footer;
