import React from "react";
import "./style/opd.css";

function Header() {
  return (
    <header>
      <h1>Welcome to OPD Medical Care</h1>
    </header>
  );
}

export default Heading;
