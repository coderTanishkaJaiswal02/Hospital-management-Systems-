import React, { useEffect, useState } from "react";
import axios from "axios";
import Fade from "react-reveal/Fade";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import "./style/dashboard.css";

const dashboard = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulating API fetch
    axios.get(//"https://jsonplaceholder.typicode.com/users"
        )
      .then((response) => {
        setData(response.data);
        setLoading(false);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  return (
    <div className="dashboard">
        <Navbar/>
      <header className="hero">
        <h2>Welcome to the Hospital Dashboard</h2>
      </header>

      <section className="stats">
        {loading ? (
          <p>Loading data...</p>
        ) : (
          data.map((item, index) => (
            <Fade key={item.id} delay={index * 100}>
              <div className="stats-card">
                <h3>{item.name}</h3>
                <p>{item.email}</p>
              </div>
            </Fade>
          ))/*<div className="stats-section">
        <StatsCard title="Total Patients" value="120" />
        <StatsCard title="Available Doctors" value="25" />
        <StatsCard title="Beds Occupied" value="75%" />
        <StatsCard title="Revenue Today" value="$50,000" />
      </div>
     */
        )}
      </section>
      <Footer/>
    </div>
  );
};

export default dashboard ;
