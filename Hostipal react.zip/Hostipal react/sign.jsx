import React from "react";
import AuthForm from "./components/AuthForm";
import Navbar from "./component/Navbar";
import Footer from "./component/Footer"
import "./styles/stylesign.css";

function sign() {
  return(
    <div className="wrapper">
        <Navbar/>
      <AuthForm />
      <Footer/>
    </div>
  );
}

export default sign;
