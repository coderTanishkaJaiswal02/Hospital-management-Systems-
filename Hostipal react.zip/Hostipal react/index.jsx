import React from "react";
import Navbar from "./components/Navbar";
import Header from "./components/Header";
import Main from "./components/Main";
import Services from "./components/Services";
import About from "./components/About";
import Footer from "./components/Footer";

function index () {
  return (
    <>
      <Navbar />
      <Header />
      <Main />
      <Services />
      <About />
      <Footer />
    </>
  );
}

export default index;
