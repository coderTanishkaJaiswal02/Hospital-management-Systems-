import React from "react";
import Navbar from "./components/Navbar";
import Heading from "./components/Heading";
import OPDForm from "./components/OPDForm";
import Footer from "./components/Footer";

function opd() {
  return (
    <div>
      <Navbar />
      <Heading />
      <OPDForm />
      <Footer />
    </div>
  );
}

export default opd;
